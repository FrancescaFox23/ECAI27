#include "kernels.h"
#include <arm_neon.h>

void conv1d_im2col(const float *x, float *col, size_t n, size_t c) {
    /* TODO 12 — Im2Col activation transform
       Arguments: x is FP32 NWC input X[N,C]; col is writable row-major
       matrix [N-2,3*C]. For each output position p, copy its three adjacent
       channel rows into one contiguous row. Overlapping input values are
       deliberately copied into more than one patch.
       Pseudocode:
         for p = 0 .. N-3:
           for r = 0 .. 2: for ch = 0 .. C-1:
             col[p*(3*C) + r*C + ch] = x[(p+r)*C + ch] */
    /* x is not read by the placeholder yet; this cast suppresses the
       unused-parameter warning until the transform is implemented. */
    (void)x;
    if (n >= 3) {
        for (size_t i = 0; i < (n-2)*3*c; ++i) {
            col[i] = 0.0f;
        }
    }
}

void conv1d_weights_to_matrix(const float *w, float *wm, size_t c, size_t k) {
    /* TODO 13 — Weight matrix transform
       Arguments: w is the original contiguous FP32 tensor W[3,C,K]; wm is
       writable row-major matrix [3*C,K]. Flatten the kernel-position and
       input-channel dimensions into GEMM's reduction dimension, retaining
       output channels as columns.
       Pseudocode:
         for r = 0 .. 2: for ch = 0 .. C-1: for out = 0 .. K-1:
           wm[(r*C+ch)*K+out] = w[(r*C+ch)*K+out]
       This layout-compatible copy is provided as a separate step so the
       convolution-to-matrix mapping is explicit. */
    /* w is not read by the placeholder yet; this cast suppresses the
       unused-parameter warning until the transform is implemented. */
    (void)w;
    for (size_t i = 0; i < 3*c*k; ++i) {
        wm[i] = 0.0f;
    }
}

void gemm_neon(const float *a, const float *b, float *out,
               size_t m, size_t n, size_t k) {
    /* TODO 14 — NEON GEMM for Im2Col
       Arguments: a is row-major [M,K] (the transformed patches), b is
       row-major [K,N] (transformed weights), and out is row-major [M,N].
       For each output row and reduction element, broadcast a[i,q], load
       several adjacent b[q,j] output channels, and multiply-accumulate into
       vector accumulators. Store vector channels and calculate any N tail
       scalarly. Here convolution uses M=N_positions, K=3*C, N=output_channels.
       Pseudocode:
         for i in M: initialize output accumulators
           for q in K: load/broadcast a[i,q]; accumulate across j using b[q,j]
           store all out[i,j] (including any scalar tail) */
    /* The placeholder does not read these inputs/dimensions yet. The casts
       suppress unused-parameter warnings; remove them when implementing. */
    (void)a;
    (void)b;
    (void)k;
    for (size_t i = 0; i < m*n; ++i) {
        out[i] = 0.0f;
    }
}
