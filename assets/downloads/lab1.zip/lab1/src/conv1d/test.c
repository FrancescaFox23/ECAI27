#include "kernels.h"
#include <math.h>
#include <stdio.h>

static int near(const float *a, const float *b, size_t n)
{
    for (size_t i = 0; i < n; ++i) {
        if (fabsf(a[i] - b[i]) > 1e-4f * (1.0f + fabsf(a[i]))) return 0;
    }
    return 1;
}

int main(void)
{
    /* Manually inspectable: C=1, K=1, X=[1,2,3,4], W=[1,10,100]. */
    float x[] = {1, 2, 3, 4}, w[] = {1, 10, 100};
    float direct[2], col[6], weights[3], gemm[2], indirect[2];
    const float *ptr[6];
    conv1d_direct(x, w, direct, 4, 1, 1);
    if (fabsf(direct[0] - 321.0f) > 1e-6f || fabsf(direct[1] - 432.0f) > 1e-6f) {
        fprintf(stderr, "FAIL: manual Conv1D values (got %g, %g)\n", direct[0], direct[1]);
        return 1;
    }
    conv1d_im2col(x, col, 4, 1);
    conv1d_weights_to_matrix(w, weights, 1, 1);
    gemm_neon(col, weights, gemm, 2, 1, 3);
    if (!near(direct, gemm, 2)) {
        fprintf(stderr, "FAIL: manual Im2Col GEMM\n");
        return 1;
    }
    conv1d_indirection(x, ptr, 4, 1);
    conv1d_indirect_neon(ptr, w, indirect, 4, 1, 1);
    if (!near(direct, indirect, 2)) {
        fprintf(stderr, "FAIL: manual indirect Conv1D\n");
        return 1;
    }

    /* Tail case exercises non-multiple-of-four C and output-channel counts. */
    enum { N = 9, C = 5, K = 7 };
    float rx[N * C], rw[3 * C * K], rd[(N - 2) * K], ri[(N - 2) * K];
    float rc[(N - 2) * 3 * C], rwm[3 * C * K], rg[(N - 2) * K];
    const float *rp[(N - 2) * 3];
    for (size_t i = 0; i < N * C; ++i) rx[i] = (float)((int)((i * 17 + 3) % 29) - 14) * 0.03f;
    for (size_t i = 0; i < 3 * C * K; ++i) rw[i] = (float)((int)((i * 11 + 1) % 31) - 15) * 0.02f;
    conv1d_direct(rx, rw, rd, N, C, K);
    conv1d_im2col(rx, rc, N, C);
    conv1d_weights_to_matrix(rw, rwm, C, K);
    gemm_neon(rc, rwm, rg, N - 2, K, 3 * C);
    if (!near(rd, rg, (N - 2) * K)) {
        fprintf(stderr, "FAIL: random Im2Col GEMM\n");
        return 1;
    }
    conv1d_indirection(rx, rp, N, C);
    conv1d_indirect_neon(rp, rw, ri, N, C, K);
    if (!near(rd, ri, (N - 2) * K)) {
        fprintf(stderr, "FAIL: random indirect NEON\n");
        return 1;
    }
    conv1d_direct_omp(rx, rw, ri, N, C, K);
    if (!near(rd, ri, (N - 2) * K)) {
        fprintf(stderr, "FAIL: OpenMP fallback/direct\n");
        return 1;
    }
    conv1d_fused_relu(rx, rw, ri, N, C, K);
    for (size_t i = 0; i < (N - 2) * K; ++i) rg[i] = rd[i] > 0.0f ? rd[i] : 0.0f;
    if (!near(ri, rg, (N - 2) * K)) {
        fprintf(stderr, "FAIL: fused ReLU\n");
        return 1;
    }
    puts("Conv1D correctness tests passed.");
    return 0;
}
