#include "kernels.h"

void conv1d_direct_omp(const float *x, const float *w, float *y,
                       size_t n, size_t c, size_t k) {
    /* TODO 17 — OpenMP direct Conv1D
       Arguments/shapes match conv1d_direct: x X[N,C], w W[3,C,K], y
       Y[N-2,K]. Output positions p are independent because each iteration
       reads inputs/weights and writes only its own output row. Add a single
       OpenMP parallel-for to the outer p loop; keep the reductions for one
       output local to that iteration. This is multi-core parallelism, unlike
       NEON's within-core SIMD.
       Pseudocode:
         parallel for p = 0 .. N-3:
           compute every output channel y[p,*] with the direct formula */
    /* The placeholder does not read these inputs/dimensions yet. The casts
       suppress unused-parameter warnings; remove them when implementing. */
    (void)x;
    (void)w;
    (void)c;
    if (n >= 3) {
        for (size_t i = 0; i < (n-2)*k; ++i) {
            y[i] = 0.0f;
        }
    }
}
