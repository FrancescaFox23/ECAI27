#include "kernels.h"
#include <arm_neon.h>

void conv1d_indirection(const float *x, const float **ptr, size_t n, size_t c) {
    /* TODO 15 — Build the pedagogical indirection table
       Arguments: x is FP32 NWC input X[N,C]; ptr is writable storage for
       3*(N-2) pointers. For output position p, ptr[p*3+r] points to the
       first channel of input row X[p+r]. Each pointer therefore addresses
       C contiguous floats. Addresses are rearranged; activation values are
       not copied.
       Pseudocode:
         for p = 0 .. N-3: for r = 0 .. 2:
           ptr[p*3+r] = &x[(p+r)*C] */
    /* The placeholder does not read x or c yet. These casts suppress
       unused-parameter warnings until the table builder is implemented. */
    (void)x;
    (void)c;
    if (n >= 3) {
        for (size_t i = 0; i < (n-2)*3; ++i) {
            ptr[i] = NULL;
        }
    }
}

void conv1d_indirect_neon(const float *const *ptr, const float *w, float *y,
                          size_t n, size_t c, size_t k) {
    /* TODO 16 — Indirect-access Conv1D with NEON
       Arguments: ptr is the table built above, with three row pointers per
       output position; w is W[3,C,K]; y is Y[N-2,K]. All values are FP32,
       NWC, kernel size 3, valid stride 1. For each output, follow the three
       pointers to read channels and accumulate weights. Vectorize adjacent
       output channels in groups of four where possible, then safely handle
       any output-channel tail. (The channel reduction still spans C.)
       Pseudocode:
         for p in N-2 output positions: for out in K channels:
           sum = 0
           for r=0..2: for ch=0..C-1:
             sum += ptr[3*p+r][ch] * w[(r*C+ch)*K+out]
           y[p*K+out] = sum
       For the SIMD version, replace groups of four out-channel scalar sums
       with NEON vector accumulators and use scalar cleanup for K%4. */
    /* The placeholder does not read these inputs/dimensions yet. The casts
       suppress unused-parameter warnings; remove them when implementing. */
    (void)ptr;
    (void)w;
    (void)c;
    if (n >= 3) {
        for (size_t i = 0; i < (n-2)*k; ++i) {
            y[i] = 0.0f;
        }
    }
}
