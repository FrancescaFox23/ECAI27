#include "kernels.h"

void conv1d_fused_relu(const float *x, const float *w, float *y,
                       size_t n, size_t c, size_t k) {
    /* TODO 18 — Conv1D fused with ReLU
       Arguments and shapes are the same as conv1d_direct: x X[N,C], w
       W[3,C,K], and y Y[N-2,K], all FP32 and NWC. Compute each convolution
       result, clamp it to max(sum,0), then store once. This avoids writing
       and rereading an unfused intermediate output.
       Pseudocode:
         for p = 0 .. N-3: for out = 0 .. K-1:
           sum = sum of x[(p+r)*C+c] * w[(r*C+c)*K+out]
           y[p*K+out] = (sum < 0) ? 0 : sum */
    /* The placeholder does not read these inputs/dimensions yet. The casts
       suppress unused-parameter warnings; remove them when implementing. */
    (void)x;
    (void)w;
    (void)c;
    if (n >= 3) {
        for (size_t i = 0; i < (n-2)*k; ++i) {
            y[i] = 0.0f;
        }
    }
}
