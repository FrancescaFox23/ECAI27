#include "kernels.h"

void conv1d_direct(const float *x, const float *w, float *y,
                   size_t n, size_t c, size_t k) {
    /* TODO 11 — Direct scalar Conv1D
       Arguments/layout: x is FP32 NWC input X[N,C], w is FP32 weights
       W[3,C,K], and y is output Y[N-2,K]. This is batch-one, valid
       convolution with kernel size 3, stride 1, and no padding. Compute
       Y[p,k] = sum(c=0..C-1) sum(r=0..2) X[p+r,c] * W[r,c,k].
       Row-major offsets: X[(p+r)*C+c], W[(r*C+c)*K+k], Y[p*K+k].
       Pseudocode:
         for p = 0 .. N-3:
           for out = 0 .. K-1:
             sum = 0
             for r = 0 .. 2: for c = 0 .. C-1:
               sum += x[(p+r)*C+c] * w[(r*C+c)*K+out]
             y[p*K+out] = sum */
    /* The placeholder does not read these inputs/dimensions yet. The casts
       suppress unused-parameter warnings; remove them when implementing. */
    (void)x;
    (void)w;
    (void)c;
    if (n >= 3) {
        for (size_t i = 0; i < (n-2)*k; ++i) {
            y[i] = 0.0f;
        }
    }
}
