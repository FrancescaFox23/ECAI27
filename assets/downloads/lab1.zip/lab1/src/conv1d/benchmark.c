#define _POSIX_C_SOURCE 200809L
#include "kernels.h"

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

enum { WARMUPS = 20, SAMPLES = 100 };
static size_t n=96,c=8,k=8,rows,count;
static float *x,*w,*reference,*relu_reference,*y,*col,*wcol;
static const float **ptr;
static double now_seconds(void)
{
    struct timespec ts;
    if(clock_gettime(CLOCK_MONOTONIC,&ts)!=0){perror("clock_gettime");exit(EXIT_FAILURE);}
    return (double)ts.tv_sec+(double)ts.tv_nsec*1e-9;
}
static int compare_double(const void *a,const void *b)
{
    double x_=*(const double*)a,y_=*(const double*)b;return (x_>y_)-(x_<y_);
}
static void report(const char *name,const double *v)
{
    double sorted[SAMPLES],mean=0.0,var=0.0;
    for(int i=0;i<SAMPLES;i++){sorted[i]=v[i];mean+=v[i]/SAMPLES;}
    qsort(sorted,SAMPLES,sizeof(sorted[0]),compare_double);
    for(int i=0;i<SAMPLES;i++){double d=v[i]-mean;var+=d*d/SAMPLES;}
    printf("%-24s %10.3f %10.3f %10.3f %10.3f\n",name,(sorted[49]+sorted[50])*0.5,sqrt(var),sorted[0],sorted[99]);
}
static int matches(const float *expected)
{
    for(size_t i=0;i<count;i++)
        if(!isfinite(y[i])||fabsf(y[i]-expected[i])>2e-3f*(1.0f+fabsf(expected[i])))return 0;
    return 1;
}
static void direct(void){conv1d_direct(x,w,y,n,c,k);}
static void transform(void){conv1d_im2col(x,col,n,c);}
static void im2col_gemm(void){gemm_neon(col,wcol,y,rows,k,3*c);}
static void im2col_end_to_end(void){transform();im2col_gemm();}
static void indirect(void){conv1d_indirect_neon(ptr,w,y,n,c,k);}
static void fused(void){conv1d_fused_relu(x,w,y,n,c,k);}
#ifdef _OPENMP
static void direct_omp(void){conv1d_direct_omp(x,w,y,n,c,k);}
#endif
typedef void (*operation)(void);
static void time_output(const char *name,operation fn,const float *expected)
{
    double samples[SAMPLES];
    for(int i=0;i<WARMUPS;i++)fn();
    if(!matches(expected)){fprintf(stderr,"%s correctness check failed\n",name);exit(EXIT_FAILURE);}
    for(int i=0;i<SAMPLES;i++){double start=now_seconds();fn();samples[i]=(now_seconds()-start)*1e6;}
    report(name,samples);
}
static int transform_correct(void)
{
    for(size_t p=0;p<rows;p++)for(size_t q=0;q<3;q++)for(size_t ch=0;ch<c;ch++)
        if(col[(p*3+q)*c+ch]!=x[(p+q)*c+ch])return 0;
    return 1;
}
static void time_transform(void)
{
    double samples[SAMPLES];
    for(int i=0;i<WARMUPS;i++)transform();
    if(!transform_correct()){fprintf(stderr,"Im2Col transform correctness check failed\n");exit(EXIT_FAILURE);}
    for(int i=0;i<SAMPLES;i++){double start=now_seconds();transform();samples[i]=(now_seconds()-start)*1e6;}
    report("Im2Col transform",samples);
}
int main(void)
{
    rows=n-2;count=rows*k;
    x=malloc(n*c*sizeof(*x));w=malloc(3*c*k*sizeof(*w));
    reference=malloc(count*sizeof(*reference));relu_reference=malloc(count*sizeof(*relu_reference));
    y=malloc(count*sizeof(*y));col=malloc(rows*3*c*sizeof(*col));wcol=malloc(3*c*k*sizeof(*wcol));
    ptr=malloc(rows*3*sizeof(*ptr));
    if(!x||!w||!reference||!relu_reference||!y||!col||!wcol||!ptr){fprintf(stderr,"Could not allocate Conv1D benchmark buffers\n");return 2;}
    for(size_t i=0;i<n*c;i++)x[i]=(float)((int)(i%31)-15)*0.01f;
    for(size_t i=0;i<3*c*k;i++)w[i]=(float)((int)(i%19)-9)*0.01f;
    for(size_t p=0;p<rows;p++)for(size_t z=0;z<k;z++){
        float sum=0;for(size_t r=0;r<3;r++)for(size_t ch=0;ch<c;ch++)sum+=x[(p+r)*c+ch]*w[(r*c+ch)*k+z];
        reference[p*k+z]=sum;relu_reference[p*k+z]=sum>0?sum:0;
    }
    transform();conv1d_weights_to_matrix(w,wcol,c,k);conv1d_indirection(x,ptr,n,c);
    printf("Conv1D N=%zu C=%zu K=%zu; warmups: %d, timed samples: %d (microseconds)\n",n,c,k,WARMUPS,SAMPLES);
    puts("Method                   median       std        min        max");
    time_output("Direct C",direct,reference);
    time_transform();
    time_output("Im2Col GEMM compute",im2col_gemm,reference);
    time_output("Im2Col end-to-end",im2col_end_to_end,reference);
    time_output("Indirect compute",indirect,reference);
#ifdef _OPENMP
    time_output("OpenMP direct Conv1D",direct_omp,reference);
#else
    puts("OpenMP direct Conv1D requires an OpenMP-enabled build.");
#endif
    time_output("Conv1D + ReLU",fused,relu_reference);
    free(x);free(w);free(reference);free(relu_reference);free(y);free(col);free(wcol);free((void*)ptr);
    return 0;
}
