#ifndef KERNELS_H
#define KERNELS_H
#include <stddef.h>

void vector_add_scalar(const float *a, const float *b, float *y, size_t n);
void vector_add_neon(const float *a, const float *b, float *y, size_t n);
float reduce_sum_scalar(const float *x, size_t n);
float reduce_sum_neon(const float *x, size_t n);
float reduce_sum_neon_omp(const float *x, size_t n);
void gemv_scalar(const float *a, const float *x, float *y, size_t m, size_t k);
void gemv_neon(const float *a, const float *x, float *y, size_t m, size_t k);
void gemm_scalar(const float *a, const float *b, float *c, size_t m, size_t n, size_t k);
void gemm_tiled(const float *a, const float *b, float *c, size_t m, size_t n, size_t k, size_t tile);
/* Batched row-major GEMM: A[batch,m,k] * B[k,n] -> C[batch,m,n]. */
void gemm_batched_scalar(const float *a, const float *b, float *c, size_t batch, size_t m, size_t n, size_t k);
void gemm_batched_tiled(const float *a, const float *b, float *c, size_t batch, size_t m, size_t n, size_t k, size_t tile);
void gemm_batched_omp_batch(const float *a, const float *b, float *c, size_t batch, size_t m, size_t n, size_t k, size_t tile);
void gemm_batched_omp_tiles(const float *a, const float *b, float *c, size_t batch, size_t m, size_t n, size_t k, size_t tile);

/* Batch-one FP32 valid Conv1D: X[N,C], W[3,C,K], Y[N-2,K], NWC. */
void conv1d_direct(const float *x, const float *w, float *y, size_t n, size_t c, size_t k);
void conv1d_im2col(const float *x, float *xcol, size_t n, size_t c);
void conv1d_weights_to_matrix(const float *w, float *wcol, size_t c, size_t k);
void gemm_neon(const float *a, const float *b, float *out, size_t m, size_t n, size_t k);
void conv1d_indirection(const float *x, const float **ptr, size_t n, size_t c);
void conv1d_indirect_neon(const float *const *ptr, const float *w, float *y, size_t n, size_t c, size_t k);
void conv1d_fused_relu(const float *x, const float *w, float *y, size_t n, size_t c, size_t k);
void conv1d_direct_omp(const float *x, const float *w, float *y, size_t n, size_t c, size_t k);
#endif
